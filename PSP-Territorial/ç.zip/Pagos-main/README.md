# PSP-Pagos – Plugin de Métodos de Pago

Plugin modular y extensible para integrar múltiples métodos de pago en aplicaciones web y móviles panameñas/latinoamericanas.

## Métodos de pago incluidos

| Nombre | Proveedor | Tipo |
|---|---|---|
| `yappy` | Yappy (Banco General / BAC) | Pago móvil QR |
| `clave` | Clave (ACH Panamá) | Pago QR interbancario |
| `punto_pago` | Punto Pago | Pasarela de pago |
| `banco_general` | Tarjetas – Banco General | Tarjeta crédito/débito |
| `paguelofacil` | Tarjetas – Paguelofacil | Tarjeta crédito/débito |
| `paypal` | PayPal | Billetera digital |
| `transferencia_bancaria` | Transferencia Bancaria | ACH / LBTR nacional |
| `transferencia_internacional` | Transferencia Internacional | Wire / SWIFT |
| `efectivo` | Efectivo | Pago en caja / contra entrega |

La arquitectura está abierta para agregar nuevos métodos sin modificar el núcleo.

---

## Instalación

```bash
npm install psp-pagos
```

---

## Uso rápido

```js
const {
  PaymentPlugin,
  FacturacionIntegration,
  PedidosIntegration,
  ContabilidadDGIIntegration,
} = require('psp-pagos');

// 1. Configurar el plugin con los proveedores que necesites
const plugin = new PaymentPlugin({
  providers: {
    yappy: {
      merchantId: 'TU_MERCHANT_ID',
      secretKey:  'TU_SECRET_KEY',
      sandbox: true,
    },
    paguelofacil: {
      cclw: 'TU_CCLW',
    },
    paypal: {
      clientId:     'TU_CLIENT_ID',
      clientSecret: 'TU_CLIENT_SECRET',
      sandbox: true,
    },
    transferencia_bancaria: {
      bankName:      'Banco Nacional de Panamá',
      accountName:   'Mi Empresa S.A.',
      accountNumber: '0000-000-000000',
    },
    efectivo: {
      instructions: 'Pague al momento de la entrega.',
    },
  },
});

// 2. Conectar con otros módulos (opcional)
plugin.registerIntegration(new FacturacionIntegration({
  facturacionUrl: 'https://mi-app/api/facturacion',
  apiKey: 'FACTURACION_KEY',
}));

plugin.registerIntegration(new PedidosIntegration({
  pedidosUrl: 'https://mi-app/api/pedidos',
  apiKey: 'PEDIDOS_KEY',
}));

plugin.registerIntegration(new ContabilidadDGIIntegration({
  contabilidadUrl: 'https://mi-app/api/contabilidad',
  ruc: '8-000-0000',
  dgiEnabled: true,
}));

// 3. Iniciar un pago
const result = await plugin.pay('yappy', {
  amount:      25.00,
  currency:    'USD',
  orderId:     'ORD-2024-001',
  description: 'Pedido #ORD-2024-001',
  phoneNumber: '+507 6000-0000', // opcional para Yappy
});

console.log(result);
// {
//   status: 'PENDING',
//   transactionId: 'YAPPY-1712345678901',
//   paymentUrl: 'https://api.yappy.com.pa/...',
//   provider: 'yappy',
//   ...
// }

// 4. Confirmar el pago (webhook / retorno del usuario)
const confirmed = await plugin.confirm('yappy', result.transactionId, {
  token: 'TOKEN_DE_YAPPY',
});

// 5. Reembolsar si es necesario
const refund = await plugin.refund('yappy', result.transactionId, 25.00);
```

---

## Agregar un proveedor personalizado

```js
const { BaseProvider, PaymentStatus } = require('psp-pagos');

class MiNuevoProvider extends BaseProvider {
  constructor(config) {
    super('mi_nuevo_metodo', config);
  }

  async initiate(paymentRequest) {
    // Lógica de tu pasarela
    return {
      status: PaymentStatus.PENDING,
      transactionId: `MNM-${Date.now()}`,
      provider: this.name,
      ...paymentRequest,
    };
  }

  async confirm(transactionId, extra = {}) {
    return { status: PaymentStatus.APPROVED, transactionId, provider: this.name };
  }

  async refund(transactionId, amount) {
    return { status: PaymentStatus.REFUNDED, transactionId, amount, provider: this.name };
  }
}

plugin.registerProvider(new MiNuevoProvider({ /* config */ }));
```

---

## Agregar una integración personalizada

```js
const { BaseIntegration } = require('psp-pagos');

class MiIntegracion extends BaseIntegration {
  constructor(config) {
    super('mi_integracion', config);
  }

  async onPaymentApproved(paymentResult, context) {
    // Notificar a tu sistema cuando el pago sea aprobado
    console.log('Pago aprobado:', paymentResult.transactionId);
  }

  async onPaymentFailed(paymentResult, context) {
    // Manejar pagos fallidos
  }

  async onPaymentRefunded(paymentResult, context) {
    // Manejar reembolsos
  }
}

plugin.registerIntegration(new MiIntegracion({}));
```

---

## Estados de pago (`PaymentStatus`)

| Estado | Descripción |
|---|---|
| `PENDING` | Pago iniciado, esperando acción del usuario |
| `PROCESSING` | En proceso (p. ej. procesando tarjeta) |
| `APPROVED` | Pago aprobado exitosamente |
| `DECLINED` | Pago rechazado por el proveedor |
| `CANCELLED` | Pago cancelado por el usuario |
| `REFUNDED` | Pago reembolsado |
| `FAILED` | Error en el proceso de pago |
| `AWAITING_CONFIRMATION` | Esperando confirmación manual (efectivo, transferencias) |

---

## Estructura del proyecto

```
psp-pagos/
├── index.js                          # Punto de entrada principal
├── src/
│   ├── PaymentPlugin.js              # Orquestador principal
│   ├── registry/
│   │   └── ProviderRegistry.js       # Registro dinámico de proveedores
│   ├── providers/
│   │   ├── BaseProvider.js           # Clase base abstracta
│   │   ├── YappyProvider.js
│   │   ├── ClaveProvider.js
│   │   ├── PuntoPagoProvider.js
│   │   ├── BancoGeneralProvider.js
│   │   ├── PaguelofacilProvider.js
│   │   ├── PayPalProvider.js
│   │   ├── TransferenciaBancariaProvider.js
│   │   ├── TransferenciaInternacionalProvider.js
│   │   └── EfectivoProvider.js
│   ├── integrations/
│   │   ├── BaseIntegration.js        # Clase base para integraciones
│   │   ├── FacturacionIntegration.js
│   │   ├── PedidosIntegration.js
│   │   └── ContabilidadDGIIntegration.js
│   └── utils/
│       ├── PaymentStatus.js
│       └── Currency.js
└── tests/                            # Suite de pruebas (Jest)
```

---

## Pruebas

```bash
npm test
```

---

## Licencia

MIT
