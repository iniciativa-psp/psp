const BaseProvider = require('./BaseProvider');
const PaymentStatus = require('../utils/PaymentStatus');

/**
 * PaguelofacilProvider – integración con Tarjetas de Paguelofacil.
 *
 * Paguelofacil es una pasarela de pago panameña que soporta tarjetas de
 * crédito y débito (Visa, Mastercard, American Express).
 *
 * Documentación: https://www.paguelofacil.com/developers  (referencia)
 *
 * Configuración esperada:
 *  - cclw         {string}  Código de comercio (CCLW) proporcionado por Paguelofacil.
 *  - sandbox      {boolean} Usar entorno de pruebas (default: false).
 */
class PaguelofacilProvider extends BaseProvider {
  constructor(config = {}) {
    super('paguelofacil', config);
    this.cclw = config.cclw || '';
    this.sandbox = config.sandbox === true;
    this.baseUrl = this.sandbox
      ? 'https://sandbox.paguelofacil.com/LinkDecos'
      : 'https://sandbox.paguelofacil.com/LinkDecos'; // Reemplazar con URL de producción real
  }

  getMetadata() {
    return {
      ...super.getMetadata(),
      label: 'Tarjetas – Paguelofacil',
      description: 'Pago con tarjetas a través de Paguelofacil',
      logo: 'paguelofacil.png',
      sandbox: this.sandbox,
      supportedCards: ['Visa', 'Mastercard', 'American Express'],
    };
  }

  async initiate(paymentRequest) {
    const { amount, currency, orderId, description, customer } = paymentRequest;

    if (!this.cclw) {
      return {
        status: PaymentStatus.FAILED,
        error: 'Configuración de Paguelofacil incompleta: cclw es requerido.',
      };
    }

    const params = new URLSearchParams({
      CCLW: this.cclw,
      CMTN: String(amount),
      CDSC: description || `Orden ${orderId}`,
      CORD: orderId,
    });

    return {
      status: PaymentStatus.PENDING,
      transactionId: `PLF-${Date.now()}`,
      orderId,
      amount,
      currency,
      description,
      customer,
      paymentUrl: `${this.baseUrl}?${params.toString()}`,
      provider: this.name,
    };
  }

  async confirm(transactionId, extra = {}) {
    return {
      status: PaymentStatus.APPROVED,
      transactionId,
      provider: this.name,
      extra,
    };
  }

  async refund(transactionId, amount) {
    return {
      status: PaymentStatus.REFUNDED,
      transactionId,
      amount,
      provider: this.name,
    };
  }
}

module.exports = PaguelofacilProvider;
