const BaseProvider = require('./BaseProvider');
const PaymentStatus = require('../utils/PaymentStatus');

/**
 * EfectivoProvider – Pago en Efectivo.
 *
 * Permite registrar pedidos que serán pagados en efectivo (contra entrega,
 * en caja, en punto de cobro, etc.).  El pago queda pendiente hasta que
 * un operador lo confirme manualmente.
 *
 * Configuración esperada:
 *  - instructions {string}  Instrucciones personalizadas para el cliente.
 *  - locations    {Array<string>} Puntos de pago disponibles (opcional).
 */
class EfectivoProvider extends BaseProvider {
  constructor(config = {}) {
    super('efectivo', config);
    this.instructions = config.instructions || 'Pague en efectivo al momento de la entrega o en caja.';
    this.locations = Array.isArray(config.locations) ? config.locations : [];
  }

  getMetadata() {
    return {
      ...super.getMetadata(),
      label: 'Efectivo',
      description: 'Pago en efectivo (contra entrega / en caja)',
      logo: 'efectivo.png',
    };
  }

  async initiate(paymentRequest) {
    const { amount, currency, orderId, description } = paymentRequest;

    return {
      status: PaymentStatus.AWAITING_CONFIRMATION,
      transactionId: `EFE-${Date.now()}`,
      orderId,
      amount,
      currency,
      description,
      instructions: this.instructions,
      locations: this.locations.length > 0 ? this.locations : undefined,
      provider: this.name,
    };
  }

  async confirm(transactionId, extra = {}) {
    return {
      status: PaymentStatus.APPROVED,
      transactionId,
      provider: this.name,
      extra,
    };
  }

  async refund(transactionId, amount) {
    return {
      status: PaymentStatus.REFUNDED,
      transactionId,
      amount,
      provider: this.name,
    };
  }
}

module.exports = EfectivoProvider;
