/**
 * BaseProvider – clase base abstracta para todos los proveedores de pago.
 *
 * Cada proveedor concreto debe extender esta clase e implementar los métodos
 * abstractos: `initiate`, `confirm` y `refund`.
 */
class BaseProvider {
  /**
   * @param {string} name  – Identificador único del proveedor (p. ej. 'yappy').
   * @param {object} config – Configuración específica del proveedor.
   */
  constructor(name, config = {}) {
    if (new.target === BaseProvider) {
      throw new Error('BaseProvider es una clase abstracta y no puede instanciarse directamente.');
    }
    this.name = name;
    this.config = config;
    this.enabled = config.enabled !== false;
  }

  /**
   * Inicia un pago.
   * @param {PaymentRequest} paymentRequest
   * @returns {Promise<PaymentResult>}
   */
  // eslint-disable-next-line no-unused-vars
  async initiate(paymentRequest) {
    throw new Error(`${this.name}.initiate() no está implementado.`);
  }

  /**
   * Confirma o verifica el estado de un pago ya iniciado.
   * @param {string} transactionId
   * @param {object} [extra] – Datos adicionales del proveedor (p. ej. token de retorno).
   * @returns {Promise<PaymentResult>}
   */
  // eslint-disable-next-line no-unused-vars
  async confirm(transactionId, extra = {}) {
    throw new Error(`${this.name}.confirm() no está implementado.`);
  }

  /**
   * Reembolsa un pago aprobado.
   * @param {string} transactionId
   * @param {number} [amount] – Monto a reembolsar; si se omite se reembolsa el total.
   * @returns {Promise<PaymentResult>}
   */
  // eslint-disable-next-line no-unused-vars
  async refund(transactionId, amount) {
    throw new Error(`${this.name}.refund() no está implementado.`);
  }

  /**
   * Indica si el proveedor está habilitado.
   * @returns {boolean}
   */
  isEnabled() {
    return this.enabled;
  }

  /**
   * Retorna los metadatos del proveedor (nombre, versión, etc.).
   * @returns {object}
   */
  getMetadata() {
    return {
      name: this.name,
      enabled: this.enabled,
    };
  }
}

module.exports = BaseProvider;
