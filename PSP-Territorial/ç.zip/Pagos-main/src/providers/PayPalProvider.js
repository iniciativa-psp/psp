const BaseProvider = require('./BaseProvider');
const PaymentStatus = require('../utils/PaymentStatus');

/**
 * PayPalProvider – integración con PayPal.
 *
 * Utiliza la API REST de PayPal (Orders API v2).
 * Documentación: https://developer.paypal.com/docs/api/orders/v2/
 *
 * Configuración esperada:
 *  - clientId     {string}  Client ID de la app PayPal.
 *  - clientSecret {string}  Client Secret de la app PayPal.
 *  - sandbox      {boolean} Usar entorno sandbox (default: false).
 */
class PayPalProvider extends BaseProvider {
  constructor(config = {}) {
    super('paypal', config);
    this.clientId = config.clientId || '';
    this.clientSecret = config.clientSecret || '';
    this.sandbox = config.sandbox === true;
    this.baseUrl = this.sandbox
      ? 'https://api-m.sandbox.paypal.com'
      : 'https://api-m.paypal.com';
  }

  getMetadata() {
    return {
      ...super.getMetadata(),
      label: 'PayPal',
      description: 'Pago con cuenta PayPal o tarjeta a través de PayPal',
      logo: 'paypal.png',
      sandbox: this.sandbox,
    };
  }

  async initiate(paymentRequest) {
    const { amount, currency, orderId, description, returnUrl, cancelUrl } = paymentRequest;

    if (!this.clientId || !this.clientSecret) {
      return {
        status: PaymentStatus.FAILED,
        error: 'Configuración de PayPal incompleta: clientId y clientSecret son requeridos.',
      };
    }

    // En producción:
    //  1. Obtener access_token con clientId + clientSecret.
    //  2. Crear la orden en /v2/checkout/orders.
    //  3. Redirigir al usuario a la URL de aprobación.
    return {
      status: PaymentStatus.PENDING,
      transactionId: `PP-${Date.now()}`,
      orderId,
      amount,
      currency: currency || 'USD',
      description,
      returnUrl,
      cancelUrl,
      approvalUrl: `${this.baseUrl}/checkoutnow?token=SIMULATED_TOKEN_${orderId}`,
      provider: this.name,
    };
  }

  async confirm(transactionId, extra = {}) {
    // En producción: capturar la orden con PATCH /v2/checkout/orders/{id}/capture
    return {
      status: PaymentStatus.APPROVED,
      transactionId,
      provider: this.name,
      extra,
    };
  }

  async refund(transactionId, amount) {
    // En producción: POST /v2/payments/captures/{captureId}/refund
    return {
      status: PaymentStatus.REFUNDED,
      transactionId,
      amount,
      provider: this.name,
    };
  }
}

module.exports = PayPalProvider;
