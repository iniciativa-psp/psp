const BaseProvider = require('./BaseProvider');
const PaymentStatus = require('../utils/PaymentStatus');

/**
 * YappyProvider – integración con Yappy (Banco General / BAC).
 *
 * Yappy es el sistema de pagos móviles más popular de Panamá.
 * Documentación oficial: https://www.yappy.com.pa/developers  (referencia)
 *
 * Configuración esperada:
 *  - merchantId   {string}  ID de comercio asignado por Yappy.
 *  - secretKey    {string}  Clave secreta para firmar peticiones.
 *  - sandbox      {boolean} Usar entorno de pruebas (default: false).
 */
class YappyProvider extends BaseProvider {
  constructor(config = {}) {
    super('yappy', config);
    this.merchantId = config.merchantId || '';
    this.secretKey = config.secretKey || '';
    this.sandbox = config.sandbox === true;
    this.baseUrl = this.sandbox
      ? 'https://sandbox.yappy.com.pa/api'
      : 'https://api.yappy.com.pa/api';
  }

  getMetadata() {
    return {
      ...super.getMetadata(),
      label: 'Yappy',
      description: 'Pago móvil Yappy (Banco General / BAC)',
      logo: 'yappy.png',
      sandbox: this.sandbox,
    };
  }

  async initiate(paymentRequest) {
    const { amount, currency, orderId, description, phoneNumber } = paymentRequest;

    if (!this.merchantId || !this.secretKey) {
      return {
        status: PaymentStatus.FAILED,
        error: 'Configuración de Yappy incompleta: merchantId y secretKey son requeridos.',
      };
    }

    // En una integración real se llamaría al endpoint de Yappy para generar
    // el deep-link / QR y redirigir al usuario.
    // Aquí simulamos la estructura de la respuesta esperada.
    return {
      status: PaymentStatus.PENDING,
      transactionId: `YAPPY-${Date.now()}`,
      orderId,
      amount,
      currency,
      description,
      phoneNumber,
      paymentUrl: `${this.baseUrl}/pay?merchant=${this.merchantId}&amount=${amount}&order=${orderId}`,
      provider: this.name,
    };
  }

  async confirm(transactionId, extra = {}) {
    // En producción: consultar el estado del pago al endpoint de Yappy.
    return {
      status: PaymentStatus.APPROVED,
      transactionId,
      provider: this.name,
      extra,
    };
  }

  async refund(transactionId, amount) {
    // En producción: llamar al endpoint de reembolso de Yappy.
    return {
      status: PaymentStatus.REFUNDED,
      transactionId,
      amount,
      provider: this.name,
    };
  }
}

module.exports = YappyProvider;
