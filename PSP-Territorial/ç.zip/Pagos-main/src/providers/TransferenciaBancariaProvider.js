const BaseProvider = require('./BaseProvider');
const PaymentStatus = require('../utils/PaymentStatus');

/**
 * TransferenciaBancariaProvider – Transferencia Bancaria nacional (ACH / LBTR).
 *
 * Permite registrar pagos realizados por transferencia bancaria dentro
 * de Panamá (ACH o LBTR). El pago queda en estado AWAITING_CONFIRMATION
 * hasta que se verifique el crédito en la cuenta del comercio.
 *
 * Configuración esperada:
 *  - bankName     {string}  Nombre del banco receptor.
 *  - accountName  {string}  Nombre del titular de la cuenta.
 *  - accountNumber{string}  Número de cuenta bancaria.
 *  - bankCode     {string}  Código ABA / código del banco (opcional).
 */
class TransferenciaBancariaProvider extends BaseProvider {
  constructor(config = {}) {
    super('transferencia_bancaria', config);
    this.bankName = config.bankName || '';
    this.accountName = config.accountName || '';
    this.accountNumber = config.accountNumber || '';
    this.bankCode = config.bankCode || '';
  }

  getMetadata() {
    return {
      ...super.getMetadata(),
      label: 'Transferencia Bancaria',
      description: 'Pago por transferencia bancaria nacional (ACH / LBTR)',
      logo: 'transferencia_bancaria.png',
    };
  }

  async initiate(paymentRequest) {
    const { amount, currency, orderId, description } = paymentRequest;

    if (!this.accountNumber) {
      return {
        status: PaymentStatus.FAILED,
        error: 'Configuración de Transferencia Bancaria incompleta: accountNumber es requerido.',
      };
    }

    return {
      status: PaymentStatus.AWAITING_CONFIRMATION,
      transactionId: `TB-${Date.now()}`,
      orderId,
      amount,
      currency,
      description,
      instructions: {
        bankName: this.bankName,
        accountName: this.accountName,
        accountNumber: this.accountNumber,
        bankCode: this.bankCode,
        reference: orderId,
        note: `Por favor incluya el número de orden "${orderId}" como referencia.`,
      },
      provider: this.name,
    };
  }

  async confirm(transactionId, extra = {}) {
    return {
      status: PaymentStatus.APPROVED,
      transactionId,
      provider: this.name,
      extra,
    };
  }

  async refund(transactionId, amount) {
    return {
      status: PaymentStatus.REFUNDED,
      transactionId,
      amount,
      provider: this.name,
    };
  }
}

module.exports = TransferenciaBancariaProvider;
