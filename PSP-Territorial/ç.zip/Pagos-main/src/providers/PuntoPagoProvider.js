const BaseProvider = require('./BaseProvider');
const PaymentStatus = require('../utils/PaymentStatus');

/**
 * PuntoPagoProvider – integración con Punto Pago.
 *
 * Punto Pago es una plataforma de pagos utilizada en Panamá y Latinoamérica.
 *
 * Configuración esperada:
 *  - merchantId   {string}  ID de comercio.
 *  - secretKey    {string}  Clave secreta.
 *  - sandbox      {boolean} Usar entorno de pruebas (default: false).
 */
class PuntoPagoProvider extends BaseProvider {
  constructor(config = {}) {
    super('punto_pago', config);
    this.merchantId = config.merchantId || '';
    this.secretKey = config.secretKey || '';
    this.sandbox = config.sandbox === true;
    this.baseUrl = this.sandbox
      ? 'https://sandbox.puntopago.com/api'
      : 'https://api.puntopago.com/api';
  }

  getMetadata() {
    return {
      ...super.getMetadata(),
      label: 'Punto Pago',
      description: 'Plataforma de pagos Punto Pago',
      logo: 'punto_pago.png',
      sandbox: this.sandbox,
    };
  }

  async initiate(paymentRequest) {
    const { amount, currency, orderId, description, customer } = paymentRequest;

    if (!this.merchantId || !this.secretKey) {
      return {
        status: PaymentStatus.FAILED,
        error: 'Configuración de Punto Pago incompleta: merchantId y secretKey son requeridos.',
      };
    }

    return {
      status: PaymentStatus.PENDING,
      transactionId: `PP-${Date.now()}`,
      orderId,
      amount,
      currency,
      description,
      customer,
      paymentUrl: `${this.baseUrl}/checkout?merchant=${this.merchantId}&order=${orderId}&amount=${amount}`,
      provider: this.name,
    };
  }

  async confirm(transactionId, extra = {}) {
    return {
      status: PaymentStatus.APPROVED,
      transactionId,
      provider: this.name,
      extra,
    };
  }

  async refund(transactionId, amount) {
    return {
      status: PaymentStatus.REFUNDED,
      transactionId,
      amount,
      provider: this.name,
    };
  }
}

module.exports = PuntoPagoProvider;
