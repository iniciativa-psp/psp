const BaseProvider = require('./BaseProvider');
const PaymentStatus = require('../utils/PaymentStatus');

/**
 * BancoGeneralProvider – integración con Tarjetas de Banco General.
 *
 * Banco General ofrece una pasarela para procesar pagos con tarjetas
 * de crédito y débito (Visa, Mastercard) emitidas por el banco.
 *
 * Configuración esperada:
 *  - merchantId   {string}  ID de comercio asignado por Banco General.
 *  - apiKey       {string}  API Key de autenticación.
 *  - sandbox      {boolean} Usar entorno de pruebas (default: false).
 */
class BancoGeneralProvider extends BaseProvider {
  constructor(config = {}) {
    super('banco_general', config);
    this.merchantId = config.merchantId || '';
    this.apiKey = config.apiKey || '';
    this.sandbox = config.sandbox === true;
    this.baseUrl = this.sandbox
      ? 'https://sandbox.bancogeneral.com/gateway/api'
      : 'https://gateway.bancogeneral.com/api';
  }

  getMetadata() {
    return {
      ...super.getMetadata(),
      label: 'Tarjetas – Banco General',
      description: 'Pago con tarjetas de crédito/débito a través de Banco General',
      logo: 'banco_general.png',
      sandbox: this.sandbox,
      supportedCards: ['Visa', 'Mastercard'],
    };
  }

  async initiate(paymentRequest) {
    const { amount, currency, orderId, description, card } = paymentRequest;

    if (!this.merchantId || !this.apiKey) {
      return {
        status: PaymentStatus.FAILED,
        error: 'Configuración de Banco General incompleta: merchantId y apiKey son requeridos.',
      };
    }

    // En producción se tokenizaría la tarjeta y se llamaría al endpoint de cobro.
    return {
      status: PaymentStatus.PROCESSING,
      transactionId: `BG-${Date.now()}`,
      orderId,
      amount,
      currency,
      description,
      card: card ? { last4: card.number ? String(card.number).slice(-4) : '****', type: card.type } : undefined,
      provider: this.name,
    };
  }

  async confirm(transactionId, extra = {}) {
    return {
      status: PaymentStatus.APPROVED,
      transactionId,
      provider: this.name,
      extra,
    };
  }

  async refund(transactionId, amount) {
    return {
      status: PaymentStatus.REFUNDED,
      transactionId,
      amount,
      provider: this.name,
    };
  }
}

module.exports = BancoGeneralProvider;
