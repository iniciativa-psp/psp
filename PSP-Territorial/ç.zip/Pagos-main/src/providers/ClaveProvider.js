const BaseProvider = require('./BaseProvider');
const PaymentStatus = require('../utils/PaymentStatus');

/**
 * ClaveProvider – integración con Clave (ACH Panamá).
 *
 * Clave es la red de pagos interbancarios de Panamá operada por ACH Panamá.
 * Permite pagos QR y transferencias entre bancos participantes.
 *
 * Configuración esperada:
 *  - merchantId   {string}  ID de comercio en la red Clave.
 *  - apiKey       {string}  API Key de autenticación.
 *  - sandbox      {boolean} Usar entorno de pruebas (default: false).
 */
class ClaveProvider extends BaseProvider {
  constructor(config = {}) {
    super('clave', config);
    this.merchantId = config.merchantId || '';
    this.apiKey = config.apiKey || '';
    this.sandbox = config.sandbox === true;
    this.baseUrl = this.sandbox
      ? 'https://sandbox.clave.com.pa/api'
      : 'https://api.clave.com.pa/api';
  }

  getMetadata() {
    return {
      ...super.getMetadata(),
      label: 'Clave',
      description: 'Pagos interbancarios QR Clave (ACH Panamá)',
      logo: 'clave.png',
      sandbox: this.sandbox,
    };
  }

  async initiate(paymentRequest) {
    const { amount, currency, orderId, description } = paymentRequest;

    if (!this.merchantId || !this.apiKey) {
      return {
        status: PaymentStatus.FAILED,
        error: 'Configuración de Clave incompleta: merchantId y apiKey son requeridos.',
      };
    }

    return {
      status: PaymentStatus.PENDING,
      transactionId: `CLAVE-${Date.now()}`,
      orderId,
      amount,
      currency,
      description,
      qrCode: `${this.baseUrl}/qr?merchant=${this.merchantId}&amount=${amount}&order=${orderId}`,
      provider: this.name,
    };
  }

  async confirm(transactionId, extra = {}) {
    return {
      status: PaymentStatus.APPROVED,
      transactionId,
      provider: this.name,
      extra,
    };
  }

  async refund(transactionId, amount) {
    return {
      status: PaymentStatus.REFUNDED,
      transactionId,
      amount,
      provider: this.name,
    };
  }
}

module.exports = ClaveProvider;
