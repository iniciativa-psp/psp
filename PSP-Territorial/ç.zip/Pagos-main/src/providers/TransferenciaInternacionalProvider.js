const BaseProvider = require('./BaseProvider');
const PaymentStatus = require('../utils/PaymentStatus');

/**
 * TransferenciaInternacionalProvider – Transferencia Bancaria Internacional (SWIFT / Wire).
 *
 * Permite registrar pagos realizados por wire transfer internacional.
 * El pago queda en estado AWAITING_CONFIRMATION hasta que se verifique
 * el crédito, ya que las transferencias internacionales pueden tardar
 * de 1 a 5 días hábiles.
 *
 * Configuración esperada:
 *  - bankName     {string}  Nombre del banco receptor.
 *  - accountName  {string}  Nombre del titular de la cuenta.
 *  - accountNumber{string}  Número de cuenta (o IBAN).
 *  - swiftCode    {string}  Código SWIFT/BIC del banco receptor.
 *  - bankAddress  {string}  Dirección del banco (requerida para SWIFT).
 *  - intermediaryBank {string} Banco intermediario (opcional).
 */
class TransferenciaInternacionalProvider extends BaseProvider {
  constructor(config = {}) {
    super('transferencia_internacional', config);
    this.bankName = config.bankName || '';
    this.accountName = config.accountName || '';
    this.accountNumber = config.accountNumber || '';
    this.swiftCode = config.swiftCode || '';
    this.bankAddress = config.bankAddress || '';
    this.intermediaryBank = config.intermediaryBank || '';
  }

  getMetadata() {
    return {
      ...super.getMetadata(),
      label: 'Transferencia Internacional',
      description: 'Pago por wire transfer / SWIFT internacional',
      logo: 'transferencia_internacional.png',
    };
  }

  async initiate(paymentRequest) {
    const { amount, currency, orderId, description } = paymentRequest;

    if (!this.accountNumber || !this.swiftCode) {
      return {
        status: PaymentStatus.FAILED,
        error: 'Configuración de Transferencia Internacional incompleta: accountNumber y swiftCode son requeridos.',
      };
    }

    return {
      status: PaymentStatus.AWAITING_CONFIRMATION,
      transactionId: `TI-${Date.now()}`,
      orderId,
      amount,
      currency: currency || 'USD',
      description,
      instructions: {
        bankName: this.bankName,
        bankAddress: this.bankAddress,
        accountName: this.accountName,
        accountNumber: this.accountNumber,
        swiftCode: this.swiftCode,
        intermediaryBank: this.intermediaryBank || undefined,
        reference: orderId,
        estimatedDays: '1-5 días hábiles',
        note: `Incluya el número de orden "${orderId}" como referencia del pago.`,
      },
      provider: this.name,
    };
  }

  async confirm(transactionId, extra = {}) {
    return {
      status: PaymentStatus.APPROVED,
      transactionId,
      provider: this.name,
      extra,
    };
  }

  async refund(transactionId, amount) {
    return {
      status: PaymentStatus.REFUNDED,
      transactionId,
      amount,
      provider: this.name,
    };
  }
}

module.exports = TransferenciaInternacionalProvider;
