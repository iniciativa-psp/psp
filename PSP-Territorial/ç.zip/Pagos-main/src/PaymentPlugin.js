const ProviderRegistry = require('./registry/ProviderRegistry');
const PaymentStatus = require('./utils/PaymentStatus');

// Proveedores incluidos por defecto
const YappyProvider = require('./providers/YappyProvider');
const ClaveProvider = require('./providers/ClaveProvider');
const PuntoPagoProvider = require('./providers/PuntoPagoProvider');
const BancoGeneralProvider = require('./providers/BancoGeneralProvider');
const PaguelofacilProvider = require('./providers/PaguelofacilProvider');
const PayPalProvider = require('./providers/PayPalProvider');
const TransferenciaBancariaProvider = require('./providers/TransferenciaBancariaProvider');
const TransferenciaInternacionalProvider = require('./providers/TransferenciaInternacionalProvider');
const EfectivoProvider = require('./providers/EfectivoProvider');

/**
 * PaymentPlugin – Núcleo del plugin PSP-Pagos.
 *
 * Orquesta todos los proveedores de pago e integraciones registradas.
 * Uso básico:
 *
 *   const plugin = new PaymentPlugin({ providers: { yappy: { merchantId: '...', secretKey: '...' } } });
 *   const result = await plugin.pay('yappy', { amount: 10, currency: 'USD', orderId: 'ORD-001' });
 *
 * Para agregar un proveedor personalizado:
 *
 *   plugin.registerProvider(new MiNuevoProvider({ ... }));
 *
 * Para conectar con otros módulos (facturación, pedidos, etc.):
 *
 *   plugin.registerIntegration(new FacturacionIntegration({ facturacionUrl: '...' }));
 */
class PaymentPlugin {
  /**
   * @param {object} config
   * @param {object} [config.providers]     – Configuración por proveedor { nombre: { ...opciones } }.
   * @param {object} [config.integrations]  – Integraciones externas a registrar.
   */
  constructor(config = {}) {
    this.config = config;
    this.registry = new ProviderRegistry();
    this._integrations = [];

    this._registerBuiltinProviders(config.providers || {});
  }

  // ─── Registro de proveedores ──────────────────────────────────────────────

  _registerBuiltinProviders(providerConfigs) {
    const builtins = [
      ['yappy',                     YappyProvider],
      ['clave',                     ClaveProvider],
      ['punto_pago',                PuntoPagoProvider],
      ['banco_general',             BancoGeneralProvider],
      ['paguelofacil',              PaguelofacilProvider],
      ['paypal',                    PayPalProvider],
      ['transferencia_bancaria',    TransferenciaBancariaProvider],
      ['transferencia_internacional', TransferenciaInternacionalProvider],
      ['efectivo',                  EfectivoProvider],
    ];

    for (const [key, ProviderClass] of builtins) {
      const cfg = providerConfigs[key] || {};
      this.registry.register(new ProviderClass(cfg));
    }
  }

  /**
   * Registra un proveedor externo/personalizado.
   * @param {BaseProvider} providerInstance
   */
  registerProvider(providerInstance) {
    this.registry.register(providerInstance);
  }

  /**
   * Reemplaza la configuración de un proveedor existente.
   * @param {BaseProvider} providerInstance
   */
  replaceProvider(providerInstance) {
    this.registry.replace(providerInstance);
  }

  // ─── Registro de integraciones ────────────────────────────────────────────

  /**
   * Registra una integración externa (facturación, pedidos, contabilidad, etc.).
   * @param {BaseIntegration} integration
   */
  registerIntegration(integration) {
    this._integrations.push(integration);
  }

  // ─── Operaciones de pago ──────────────────────────────────────────────────

  /**
   * Inicia un pago con el proveedor especificado.
   *
   * @param {string} providerName  – Nombre del proveedor (p. ej. 'yappy').
   * @param {object} paymentRequest
   * @param {number}  paymentRequest.amount       – Monto a cobrar.
   * @param {string}  paymentRequest.currency     – Moneda (default: 'USD').
   * @param {string}  paymentRequest.orderId      – ID único del pedido.
   * @param {string}  [paymentRequest.description]
   * @param {object}  [context] – Datos de contexto para las integraciones.
   * @returns {Promise<object>} Resultado del pago.
   */
  async pay(providerName, paymentRequest, context = {}) {
    const provider = this.registry.get(providerName);

    if (!provider.isEnabled()) {
      return {
        status: PaymentStatus.FAILED,
        error: `El proveedor "${providerName}" está deshabilitado.`,
      };
    }

    const result = await provider.initiate(paymentRequest);

    if (result.status === PaymentStatus.APPROVED) {
      await this._notifyIntegrations('onPaymentApproved', result, context);
    } else if (result.status === PaymentStatus.FAILED) {
      await this._notifyIntegrations('onPaymentFailed', result, context);
    }

    return result;
  }

  /**
   * Confirma / verifica el estado de un pago ya iniciado.
   *
   * @param {string} providerName
   * @param {string} transactionId
   * @param {object} [extra]
   * @param {object} [context]
   * @returns {Promise<object>}
   */
  async confirm(providerName, transactionId, extra = {}, context = {}) {
    const provider = this.registry.get(providerName);
    const result = await provider.confirm(transactionId, extra);

    if (result.status === PaymentStatus.APPROVED) {
      await this._notifyIntegrations('onPaymentApproved', result, context);
    } else if ([PaymentStatus.FAILED, PaymentStatus.DECLINED].includes(result.status)) {
      await this._notifyIntegrations('onPaymentFailed', result, context);
    }

    return result;
  }

  /**
   * Reembolsa un pago aprobado.
   *
   * @param {string} providerName
   * @param {string} transactionId
   * @param {number} [amount]
   * @param {object} [context]
   * @returns {Promise<object>}
   */
  async refund(providerName, transactionId, amount, context = {}) {
    const provider = this.registry.get(providerName);
    const result = await provider.refund(transactionId, amount);

    if (result.status === PaymentStatus.REFUNDED) {
      await this._notifyIntegrations('onPaymentRefunded', result, context);
    }

    return result;
  }

  // ─── Utilidades ───────────────────────────────────────────────────────────

  /**
   * Lista todos los proveedores disponibles con sus metadatos.
   * @param {boolean} [onlyEnabled=false]
   * @returns {object[]}
   */
  listProviders(onlyEnabled = false) {
    return this.registry.listMetadata(onlyEnabled);
  }

  /**
   * Verifica si un proveedor está disponible (registrado y habilitado).
   * @param {string} providerName
   * @returns {boolean}
   */
  isAvailable(providerName) {
    if (!this.registry.has(providerName)) return false;
    return this.registry.get(providerName).isEnabled();
  }

  // ─── Privado ──────────────────────────────────────────────────────────────

  async _notifyIntegrations(event, result, context) {
    const enabled = this._integrations.filter((i) => i.isEnabled());
    await Promise.all(
      enabled.map((integration) => {
        if (typeof integration[event] === 'function') {
          return integration[event](result, context).catch((err) => {
            // Una integración que falla no debe interrumpir el flujo de pago.
            console.error(`[PSP-Pagos] Error en integración "${integration.name}" (${event}):`, err.message);
          });
        }
        return Promise.resolve();
      })
    );
  }
}

module.exports = PaymentPlugin;
