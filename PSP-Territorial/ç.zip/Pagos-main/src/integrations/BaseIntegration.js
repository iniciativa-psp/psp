/**
 * BaseIntegration – Clase base para integraciones con otros plugins/sistemas.
 *
 * Permite que el plugin PSP-Pagos se comunique con módulos como
 * Facturación, Pedidos, Contabilidad/DGI, etc.
 */
class BaseIntegration {
  /**
   * @param {string} name – Identificador único de la integración.
   * @param {object} config
   */
  constructor(name, config = {}) {
    if (new.target === BaseIntegration) {
      throw new Error('BaseIntegration es abstracta y no puede instanciarse directamente.');
    }
    this.name = name;
    this.config = config;
    this.enabled = config.enabled !== false;
  }

  /**
   * Se invoca cuando un pago es exitoso.
   * @param {object} paymentResult
   * @param {object} [context] – Datos adicionales del pedido/factura.
   * @returns {Promise<void>}
   */
  // eslint-disable-next-line no-unused-vars
  async onPaymentApproved(paymentResult, context = {}) {
    throw new Error(`${this.name}.onPaymentApproved() no está implementado.`);
  }

  /**
   * Se invoca cuando un pago es rechazado o falla.
   * @param {object} paymentResult
   * @param {object} [context]
   * @returns {Promise<void>}
   */
  // eslint-disable-next-line no-unused-vars
  async onPaymentFailed(paymentResult, context = {}) {}

  /**
   * Se invoca cuando un pago es reembolsado.
   * @param {object} paymentResult
   * @param {object} [context]
   * @returns {Promise<void>}
   */
  // eslint-disable-next-line no-unused-vars
  async onPaymentRefunded(paymentResult, context = {}) {}

  isEnabled() {
    return this.enabled;
  }
}

module.exports = BaseIntegration;
