const BaseIntegration = require('./BaseIntegration');

/**
 * FacturacionIntegration – Integración con el módulo de Facturación.
 *
 * Al aprobarse un pago, genera automáticamente la factura correspondiente
 * en el sistema de facturación configurado.
 *
 * Configuración esperada:
 *  - facturacionUrl {string}  URL base del módulo de facturación.
 *  - apiKey         {string}  Clave de autenticación.
 *  - autoGenerate   {boolean} Si se genera la factura automáticamente (default: true).
 */
class FacturacionIntegration extends BaseIntegration {
  constructor(config = {}) {
    super('facturacion', config);
    this.facturacionUrl = config.facturacionUrl || '';
    this.apiKey = config.apiKey || '';
    this.autoGenerate = config.autoGenerate !== false;
  }

  async onPaymentApproved(paymentResult, context = {}) {
    if (!this.enabled || !this.autoGenerate) return;

    const invoice = {
      transactionId: paymentResult.transactionId,
      orderId: paymentResult.orderId,
      amount: paymentResult.amount,
      currency: paymentResult.currency,
      provider: paymentResult.provider,
      customer: context.customer,
      items: context.items,
      issuedAt: new Date().toISOString(),
    };

    // En producción se llamaría al módulo de facturación vía HTTP o evento.
    if (this.facturacionUrl && this.apiKey) {
      // fetch(`${this.facturacionUrl}/invoices`, { method: 'POST', body: JSON.stringify(invoice), ... })
    }

    return invoice;
  }

  async onPaymentRefunded(paymentResult, context = {}) {
    if (!this.enabled) return;

    // En producción: emitir nota de crédito en el módulo de facturación.
    return {
      creditNote: true,
      transactionId: paymentResult.transactionId,
      amount: paymentResult.amount,
      context,
    };
  }
}

module.exports = FacturacionIntegration;
