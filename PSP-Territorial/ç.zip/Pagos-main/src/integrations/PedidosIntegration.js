const BaseIntegration = require('./BaseIntegration');

/**
 * PedidosIntegration – Integración con el módulo de Pedidos.
 *
 * Al aprobarse un pago, actualiza el estado del pedido correspondiente
 * en el sistema de gestión de pedidos.
 *
 * Configuración esperada:
 *  - pedidosUrl   {string}  URL base del módulo de pedidos.
 *  - apiKey       {string}  Clave de autenticación.
 *  - approvedStatus {string} Estado a asignar al pedido aprobado (default: 'PAID').
 *  - failedStatus   {string} Estado al fallar (default: 'PAYMENT_FAILED').
 */
class PedidosIntegration extends BaseIntegration {
  constructor(config = {}) {
    super('pedidos', config);
    this.pedidosUrl = config.pedidosUrl || '';
    this.apiKey = config.apiKey || '';
    this.approvedStatus = config.approvedStatus || 'PAID';
    this.failedStatus = config.failedStatus || 'PAYMENT_FAILED';
  }

  async onPaymentApproved(paymentResult, context = {}) {
    if (!this.enabled) return;

    const update = {
      orderId: paymentResult.orderId,
      status: this.approvedStatus,
      transactionId: paymentResult.transactionId,
      paidAt: new Date().toISOString(),
      provider: paymentResult.provider,
      context,
    };

    // En producción: PATCH /orders/{orderId}
    if (this.pedidosUrl && this.apiKey) {
      // fetch(`${this.pedidosUrl}/orders/${paymentResult.orderId}`, { method: 'PATCH', ... })
    }

    return update;
  }

  async onPaymentFailed(paymentResult, context = {}) {
    if (!this.enabled) return;

    const update = {
      orderId: paymentResult.orderId,
      status: this.failedStatus,
      transactionId: paymentResult.transactionId,
      failedAt: new Date().toISOString(),
      provider: paymentResult.provider,
      context,
    };

    return update;
  }

  async onPaymentRefunded(paymentResult, context = {}) {
    if (!this.enabled) return;

    return {
      orderId: paymentResult.orderId,
      status: 'REFUNDED',
      transactionId: paymentResult.transactionId,
      refundedAt: new Date().toISOString(),
      context,
    };
  }
}

module.exports = PedidosIntegration;
