const BaseIntegration = require('./BaseIntegration');

/**
 * ContabilidadDGIIntegration – Integración con Contabilidad y DGI (Panama).
 *
 * Al aprobarse un pago, registra el asiento contable correspondiente y
 * prepara los datos para el reporte a la Dirección General de Ingresos (DGI)
 * de Panamá (e-Tax 2.0 / Facturación Electrónica).
 *
 * Configuración esperada:
 *  - contabilidadUrl {string}  URL base del módulo de contabilidad.
 *  - apiKey          {string}  Clave de autenticación.
 *  - ruc             {string}  RUC del contribuyente (para DGI).
 *  - dgiEnabled      {boolean} Enviar datos a DGI (default: false).
 *  - dgiUrl          {string}  URL del servicio DGI (e-Tax).
 */
class ContabilidadDGIIntegration extends BaseIntegration {
  constructor(config = {}) {
    super('contabilidad_dgi', config);
    this.contabilidadUrl = config.contabilidadUrl || '';
    this.apiKey = config.apiKey || '';
    this.ruc = config.ruc || '';
    this.dgiEnabled = config.dgiEnabled === true;
    this.dgiUrl = config.dgiUrl || 'https://etax2.dgi.mef.gob.pa';
  }

  async onPaymentApproved(paymentResult, context = {}) {
    if (!this.enabled) return;

    const entry = {
      transactionId: paymentResult.transactionId,
      orderId: paymentResult.orderId,
      amount: paymentResult.amount,
      currency: paymentResult.currency,
      provider: paymentResult.provider,
      debitAccount: context.debitAccount || 'Caja y Bancos',
      creditAccount: context.creditAccount || 'Ingresos por Ventas',
      postedAt: new Date().toISOString(),
      ruc: this.ruc,
    };

    // En producción: registrar asiento en módulo contable.
    if (this.contabilidadUrl && this.apiKey) {
      // fetch(`${this.contabilidadUrl}/entries`, { method: 'POST', body: JSON.stringify(entry), ... })
    }

    // Reporte a DGI (e-Tax 2.0) si está habilitado.
    if (this.dgiEnabled && this.ruc) {
      entry.dgiReported = true;
      // En producción: enviar al endpoint e-Tax de DGI.
    }

    return entry;
  }

  async onPaymentRefunded(paymentResult, context = {}) {
    if (!this.enabled) return;

    return {
      transactionId: paymentResult.transactionId,
      amount: paymentResult.amount,
      type: 'REVERSAL',
      postedAt: new Date().toISOString(),
      ruc: this.ruc,
      context,
    };
  }
}

module.exports = ContabilidadDGIIntegration;
