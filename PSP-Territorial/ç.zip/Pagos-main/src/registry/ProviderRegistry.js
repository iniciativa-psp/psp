/**
 * ProviderRegistry – Registro central de proveedores de pago.
 *
 * Permite registrar, obtener y listar proveedores de forma dinámica,
 * manteniendo la puerta abierta para agregar nuevos métodos de pago
 * en el futuro sin modificar el núcleo del plugin.
 */
class ProviderRegistry {
  constructor() {
    this._providers = new Map();
  }

  /**
   * Registra un proveedor en el registro.
   * @param {BaseProvider} provider – Instancia de un proveedor concreto.
   * @throws {Error} Si ya existe un proveedor con el mismo nombre.
   */
  register(provider) {
    if (!provider || !provider.name) {
      throw new Error('El proveedor debe tener un nombre válido.');
    }
    if (this._providers.has(provider.name)) {
      throw new Error(`Ya existe un proveedor registrado con el nombre "${provider.name}".`);
    }
    this._providers.set(provider.name, provider);
  }

  /**
   * Reemplaza o actualiza un proveedor existente.
   * @param {BaseProvider} provider
   */
  replace(provider) {
    if (!provider || !provider.name) {
      throw new Error('El proveedor debe tener un nombre válido.');
    }
    this._providers.set(provider.name, provider);
  }

  /**
   * Elimina un proveedor del registro.
   * @param {string} name
   */
  unregister(name) {
    this._providers.delete(name);
  }

  /**
   * Obtiene un proveedor por nombre.
   * @param {string} name
   * @returns {BaseProvider}
   * @throws {Error} Si el proveedor no está registrado.
   */
  get(name) {
    const provider = this._providers.get(name);
    if (!provider) {
      throw new Error(`Proveedor "${name}" no encontrado en el registro.`);
    }
    return provider;
  }

  /**
   * Verifica si un proveedor está registrado.
   * @param {string} name
   * @returns {boolean}
   */
  has(name) {
    return this._providers.has(name);
  }

  /**
   * Lista todos los proveedores registrados.
   * @param {boolean} [onlyEnabled=false] – Si es true, solo devuelve los habilitados.
   * @returns {BaseProvider[]}
   */
  list(onlyEnabled = false) {
    const all = Array.from(this._providers.values());
    return onlyEnabled ? all.filter((p) => p.isEnabled()) : all;
  }

  /**
   * Lista los metadatos de todos los proveedores (útil para mostrar en UI).
   * @param {boolean} [onlyEnabled=false]
   * @returns {object[]}
   */
  listMetadata(onlyEnabled = false) {
    return this.list(onlyEnabled).map((p) => p.getMetadata());
  }

  /**
   * Retorna el número de proveedores registrados.
   * @returns {number}
   */
  count() {
    return this._providers.size;
  }
}

module.exports = ProviderRegistry;
