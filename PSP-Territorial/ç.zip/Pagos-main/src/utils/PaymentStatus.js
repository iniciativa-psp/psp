/**
 * Estados posibles de un pago en el sistema PSP-Pagos.
 */
const PaymentStatus = Object.freeze({
  PENDING: 'PENDING',
  PROCESSING: 'PROCESSING',
  APPROVED: 'APPROVED',
  DECLINED: 'DECLINED',
  CANCELLED: 'CANCELLED',
  REFUNDED: 'REFUNDED',
  FAILED: 'FAILED',
  AWAITING_CONFIRMATION: 'AWAITING_CONFIRMATION',
});

module.exports = PaymentStatus;
