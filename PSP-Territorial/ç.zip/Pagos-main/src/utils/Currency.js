/**
 * Monedas soportadas por el sistema PSP-Pagos.
 */
const Currency = Object.freeze({
  USD: 'USD',
  EUR: 'EUR',
  PAB: 'PAB', // Balboa panameño (equivalente al dólar)
});

/**
 * Formatea un monto con dos decimales y el símbolo de la moneda.
 * @param {number} amount
 * @param {string} currency
 * @returns {string}
 */
function formatAmount(amount, currency = Currency.USD) {
  const symbols = { USD: '$', EUR: '€', PAB: 'B/.' };
  const symbol = symbols[currency] || currency;
  return `${symbol}${Number(amount).toFixed(2)}`;
}

module.exports = { Currency, formatAmount };
