'use strict';

/**
 * PSP-Pagos – Plugin principal de métodos de pago.
 *
 * Exporta el plugin central, todos los proveedores incluidos, las integraciones
 * y las utilidades, de forma que cualquier aplicación pueda importar solo lo que
 * necesita.
 *
 * Uso rápido:
 *
 *   const { PaymentPlugin } = require('psp-pagos');
 *
 *   const plugin = new PaymentPlugin({
 *     providers: {
 *       yappy: { merchantId: 'MI_MERCHANT', secretKey: 'MI_SECRET' },
 *       paypal: { clientId: 'CLIENT_ID', clientSecret: 'CLIENT_SECRET', sandbox: true },
 *       efectivo: { instructions: 'Pague en caja al recoger su pedido.' },
 *     },
 *   });
 *
 *   const result = await plugin.pay('yappy', {
 *     amount: 25.00,
 *     currency: 'USD',
 *     orderId: 'ORD-2024-001',
 *     description: 'Pedido de prueba',
 *   });
 */

const PaymentPlugin = require('./src/PaymentPlugin');

// Providers
const BaseProvider = require('./src/providers/BaseProvider');
const YappyProvider = require('./src/providers/YappyProvider');
const ClaveProvider = require('./src/providers/ClaveProvider');
const PuntoPagoProvider = require('./src/providers/PuntoPagoProvider');
const BancoGeneralProvider = require('./src/providers/BancoGeneralProvider');
const PaguelofacilProvider = require('./src/providers/PaguelofacilProvider');
const PayPalProvider = require('./src/providers/PayPalProvider');
const TransferenciaBancariaProvider = require('./src/providers/TransferenciaBancariaProvider');
const TransferenciaInternacionalProvider = require('./src/providers/TransferenciaInternacionalProvider');
const EfectivoProvider = require('./src/providers/EfectivoProvider');

// Registry
const ProviderRegistry = require('./src/registry/ProviderRegistry');

// Integrations
const BaseIntegration = require('./src/integrations/BaseIntegration');
const FacturacionIntegration = require('./src/integrations/FacturacionIntegration');
const PedidosIntegration = require('./src/integrations/PedidosIntegration');
const ContabilidadDGIIntegration = require('./src/integrations/ContabilidadDGIIntegration');

// Utils
const PaymentStatus = require('./src/utils/PaymentStatus');
const { Currency, formatAmount } = require('./src/utils/Currency');

module.exports = {
  // Plugin principal
  PaymentPlugin,

  // Proveedores
  BaseProvider,
  YappyProvider,
  ClaveProvider,
  PuntoPagoProvider,
  BancoGeneralProvider,
  PaguelofacilProvider,
  PayPalProvider,
  TransferenciaBancariaProvider,
  TransferenciaInternacionalProvider,
  EfectivoProvider,

  // Registro
  ProviderRegistry,

  // Integraciones
  BaseIntegration,
  FacturacionIntegration,
  PedidosIntegration,
  ContabilidadDGIIntegration,

  // Utilidades
  PaymentStatus,
  Currency,
  formatAmount,
};
