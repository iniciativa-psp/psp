const ProviderRegistry = require('../../src/registry/ProviderRegistry');
const YappyProvider = require('../../src/providers/YappyProvider');
const EfectivoProvider = require('../../src/providers/EfectivoProvider');

describe('ProviderRegistry', () => {
  let registry;

  beforeEach(() => {
    registry = new ProviderRegistry();
  });

  test('registra y obtiene un proveedor', () => {
    const yappy = new YappyProvider({ merchantId: 'M1', secretKey: 'S1' });
    registry.register(yappy);
    expect(registry.get('yappy')).toBe(yappy);
  });

  test('lanza error al registrar un proveedor duplicado', () => {
    registry.register(new YappyProvider({}));
    expect(() => registry.register(new YappyProvider({}))).toThrow(/ya existe/i);
  });

  test('replace sobreescribe un proveedor existente', () => {
    const y1 = new YappyProvider({ merchantId: 'OLD' });
    const y2 = new YappyProvider({ merchantId: 'NEW' });
    registry.register(y1);
    registry.replace(y2);
    expect(registry.get('yappy')).toBe(y2);
  });

  test('unregister elimina un proveedor', () => {
    registry.register(new YappyProvider({}));
    registry.unregister('yappy');
    expect(registry.has('yappy')).toBe(false);
  });

  test('has retorna false si el proveedor no existe', () => {
    expect(registry.has('inexistente')).toBe(false);
  });

  test('get lanza error si el proveedor no existe', () => {
    expect(() => registry.get('inexistente')).toThrow(/no encontrado/i);
  });

  test('list devuelve todos los proveedores', () => {
    registry.register(new YappyProvider({}));
    registry.register(new EfectivoProvider({}));
    expect(registry.list()).toHaveLength(2);
  });

  test('list con onlyEnabled=true filtra deshabilitados', () => {
    registry.register(new YappyProvider({ enabled: false }));
    registry.register(new EfectivoProvider({ enabled: true }));
    expect(registry.list(true)).toHaveLength(1);
    expect(registry.list(true)[0].name).toBe('efectivo');
  });

  test('listMetadata retorna arreglo de metadatos', () => {
    registry.register(new YappyProvider({}));
    const metadata = registry.listMetadata();
    expect(Array.isArray(metadata)).toBe(true);
    expect(metadata[0]).toHaveProperty('name', 'yappy');
  });

  test('count retorna el número correcto de proveedores', () => {
    expect(registry.count()).toBe(0);
    registry.register(new YappyProvider({}));
    expect(registry.count()).toBe(1);
  });

  test('lanza error al registrar proveedor sin nombre', () => {
    expect(() => registry.register({})).toThrow();
  });
});
