const PaymentStatus = require('../../src/utils/PaymentStatus');
const YappyProvider = require('../../src/providers/YappyProvider');
const ClaveProvider = require('../../src/providers/ClaveProvider');
const PuntoPagoProvider = require('../../src/providers/PuntoPagoProvider');
const BancoGeneralProvider = require('../../src/providers/BancoGeneralProvider');
const PaguelofacilProvider = require('../../src/providers/PaguelofacilProvider');
const PayPalProvider = require('../../src/providers/PayPalProvider');
const TransferenciaBancariaProvider = require('../../src/providers/TransferenciaBancariaProvider');
const TransferenciaInternacionalProvider = require('../../src/providers/TransferenciaInternacionalProvider');
const EfectivoProvider = require('../../src/providers/EfectivoProvider');

const COMMON_REQUEST = {
  amount: 50,
  currency: 'USD',
  orderId: 'ORD-TEST-001',
  description: 'Prueba de pago',
};

// ─── Yappy ───────────────────────────────────────────────────────────────────
describe('YappyProvider', () => {
  test('falla si falta configuración', async () => {
    const provider = new YappyProvider({});
    const result = await provider.initiate(COMMON_REQUEST);
    expect(result.status).toBe(PaymentStatus.FAILED);
  });

  test('retorna PENDING con configuración válida', async () => {
    const provider = new YappyProvider({ merchantId: 'M1', secretKey: 'S1' });
    const result = await provider.initiate(COMMON_REQUEST);
    expect(result.status).toBe(PaymentStatus.PENDING);
    expect(result.transactionId).toMatch(/^YAPPY-/);
    expect(result.provider).toBe('yappy');
    expect(result.paymentUrl).toBeTruthy();
  });

  test('confirm retorna APPROVED', async () => {
    const provider = new YappyProvider({ merchantId: 'M1', secretKey: 'S1' });
    const result = await provider.confirm('YAPPY-123');
    expect(result.status).toBe(PaymentStatus.APPROVED);
  });

  test('refund retorna REFUNDED', async () => {
    const provider = new YappyProvider({ merchantId: 'M1', secretKey: 'S1' });
    const result = await provider.refund('YAPPY-123', 50);
    expect(result.status).toBe(PaymentStatus.REFUNDED);
  });

  test('getMetadata tiene label correcto', () => {
    const provider = new YappyProvider({ merchantId: 'M1', secretKey: 'S1' });
    expect(provider.getMetadata().label).toBe('Yappy');
  });

  test('usa sandbox URL cuando sandbox=true', () => {
    const provider = new YappyProvider({ merchantId: 'M1', secretKey: 'S1', sandbox: true });
    expect(provider.baseUrl).toContain('sandbox');
  });
});

// ─── Clave ───────────────────────────────────────────────────────────────────
describe('ClaveProvider', () => {
  test('falla si falta configuración', async () => {
    const provider = new ClaveProvider({});
    const result = await provider.initiate(COMMON_REQUEST);
    expect(result.status).toBe(PaymentStatus.FAILED);
  });

  test('retorna PENDING con configuración válida', async () => {
    const provider = new ClaveProvider({ merchantId: 'M1', apiKey: 'K1' });
    const result = await provider.initiate(COMMON_REQUEST);
    expect(result.status).toBe(PaymentStatus.PENDING);
    expect(result.transactionId).toMatch(/^CLAVE-/);
    expect(result.qrCode).toBeTruthy();
  });

  test('confirm retorna APPROVED', async () => {
    const provider = new ClaveProvider({ merchantId: 'M1', apiKey: 'K1' });
    const result = await provider.confirm('CLAVE-123');
    expect(result.status).toBe(PaymentStatus.APPROVED);
  });
});

// ─── Punto Pago ──────────────────────────────────────────────────────────────
describe('PuntoPagoProvider', () => {
  test('falla si falta configuración', async () => {
    const provider = new PuntoPagoProvider({});
    const result = await provider.initiate(COMMON_REQUEST);
    expect(result.status).toBe(PaymentStatus.FAILED);
  });

  test('retorna PENDING con configuración válida', async () => {
    const provider = new PuntoPagoProvider({ merchantId: 'M1', secretKey: 'S1' });
    const result = await provider.initiate(COMMON_REQUEST);
    expect(result.status).toBe(PaymentStatus.PENDING);
    expect(result.transactionId).toMatch(/^PP-/);
  });
});

// ─── Banco General ───────────────────────────────────────────────────────────
describe('BancoGeneralProvider', () => {
  test('falla si falta configuración', async () => {
    const provider = new BancoGeneralProvider({});
    const result = await provider.initiate(COMMON_REQUEST);
    expect(result.status).toBe(PaymentStatus.FAILED);
  });

  test('retorna PROCESSING con configuración válida', async () => {
    const provider = new BancoGeneralProvider({ merchantId: 'M1', apiKey: 'K1' });
    const result = await provider.initiate({ ...COMMON_REQUEST, card: { number: '4111111111111111', type: 'Visa' } });
    expect(result.status).toBe(PaymentStatus.PROCESSING);
    expect(result.card.last4).toBe('1111');
  });

  test('getMetadata tiene supportedCards', () => {
    const provider = new BancoGeneralProvider({ merchantId: 'M1', apiKey: 'K1' });
    expect(provider.getMetadata().supportedCards).toContain('Visa');
  });
});

// ─── Paguelofacil ─────────────────────────────────────────────────────────────
describe('PaguelofacilProvider', () => {
  test('falla si falta cclw', async () => {
    const provider = new PaguelofacilProvider({});
    const result = await provider.initiate(COMMON_REQUEST);
    expect(result.status).toBe(PaymentStatus.FAILED);
  });

  test('retorna PENDING con cclw válido', async () => {
    const provider = new PaguelofacilProvider({ cclw: 'CCLW123' });
    const result = await provider.initiate(COMMON_REQUEST);
    expect(result.status).toBe(PaymentStatus.PENDING);
    expect(result.paymentUrl).toContain('CCLW123');
  });
});

// ─── PayPal ───────────────────────────────────────────────────────────────────
describe('PayPalProvider', () => {
  test('falla si falta configuración', async () => {
    const provider = new PayPalProvider({});
    const result = await provider.initiate(COMMON_REQUEST);
    expect(result.status).toBe(PaymentStatus.FAILED);
  });

  test('retorna PENDING con configuración válida', async () => {
    const provider = new PayPalProvider({ clientId: 'CID', clientSecret: 'CS', sandbox: true });
    const result = await provider.initiate(COMMON_REQUEST);
    expect(result.status).toBe(PaymentStatus.PENDING);
    expect(result.approvalUrl).toBeTruthy();
  });

  test('sandbox usa URL sandbox', () => {
    const provider = new PayPalProvider({ clientId: 'X', clientSecret: 'Y', sandbox: true });
    expect(provider.baseUrl).toContain('sandbox');
  });
});

// ─── Transferencia Bancaria ──────────────────────────────────────────────────
describe('TransferenciaBancariaProvider', () => {
  test('falla si falta accountNumber', async () => {
    const provider = new TransferenciaBancariaProvider({});
    const result = await provider.initiate(COMMON_REQUEST);
    expect(result.status).toBe(PaymentStatus.FAILED);
  });

  test('retorna AWAITING_CONFIRMATION con config válida', async () => {
    const provider = new TransferenciaBancariaProvider({
      bankName: 'Banco Nacional',
      accountName: 'Mi Empresa',
      accountNumber: '123456789',
    });
    const result = await provider.initiate(COMMON_REQUEST);
    expect(result.status).toBe(PaymentStatus.AWAITING_CONFIRMATION);
    expect(result.instructions.accountNumber).toBe('123456789');
    expect(result.instructions.reference).toBe(COMMON_REQUEST.orderId);
  });
});

// ─── Transferencia Internacional ─────────────────────────────────────────────
describe('TransferenciaInternacionalProvider', () => {
  test('falla si falta accountNumber o swiftCode', async () => {
    const provider = new TransferenciaInternacionalProvider({});
    const result = await provider.initiate(COMMON_REQUEST);
    expect(result.status).toBe(PaymentStatus.FAILED);
  });

  test('retorna AWAITING_CONFIRMATION con config válida', async () => {
    const provider = new TransferenciaInternacionalProvider({
      bankName: 'Global Bank',
      accountNumber: 'ACC-999',
      swiftCode: 'GBKPAPAP',
    });
    const result = await provider.initiate(COMMON_REQUEST);
    expect(result.status).toBe(PaymentStatus.AWAITING_CONFIRMATION);
    expect(result.instructions.swiftCode).toBe('GBKPAPAP');
  });

  test('instructions.intermediaryBank es undefined si no se configura', async () => {
    const provider = new TransferenciaInternacionalProvider({
      accountNumber: 'ACC-999',
      swiftCode: 'GBKPAPAP',
    });
    const result = await provider.initiate(COMMON_REQUEST);
    expect(result.instructions.intermediaryBank).toBeUndefined();
  });
});

// ─── Efectivo ─────────────────────────────────────────────────────────────────
describe('EfectivoProvider', () => {
  test('retorna AWAITING_CONFIRMATION siempre', async () => {
    const provider = new EfectivoProvider({});
    const result = await provider.initiate(COMMON_REQUEST);
    expect(result.status).toBe(PaymentStatus.AWAITING_CONFIRMATION);
    expect(result.provider).toBe('efectivo');
  });

  test('usa instrucciones personalizadas', async () => {
    const provider = new EfectivoProvider({ instructions: 'Pague en caja 1.' });
    const result = await provider.initiate(COMMON_REQUEST);
    expect(result.instructions).toBe('Pague en caja 1.');
  });

  test('incluye locations si se configuran', async () => {
    const provider = new EfectivoProvider({ locations: ['Caja central', 'Sucursal Norte'] });
    const result = await provider.initiate(COMMON_REQUEST);
    expect(result.locations).toHaveLength(2);
  });

  test('locations es undefined si no se configuran', async () => {
    const provider = new EfectivoProvider({});
    const result = await provider.initiate(COMMON_REQUEST);
    expect(result.locations).toBeUndefined();
  });
});
