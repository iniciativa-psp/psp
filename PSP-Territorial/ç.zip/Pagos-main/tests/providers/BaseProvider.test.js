const BaseProvider = require('../../src/providers/BaseProvider');

describe('BaseProvider', () => {
  test('no puede instanciarse directamente', () => {
    expect(() => new BaseProvider('test', {})).toThrow(/abstracta/i);
  });

  test('una subclase puede instanciarse', () => {
    class ConcreteProvider extends BaseProvider {
      async initiate() { return {}; }
      async confirm() { return {}; }
      async refund() { return {}; }
    }
    const p = new ConcreteProvider('concrete', {});
    expect(p.name).toBe('concrete');
    expect(p.isEnabled()).toBe(true);
  });

  test('isEnabled retorna false si config.enabled es false', () => {
    class ConcreteProvider extends BaseProvider {
      async initiate() { return {}; }
    }
    const p = new ConcreteProvider('concrete', { enabled: false });
    expect(p.isEnabled()).toBe(false);
  });

  test('getMetadata retorna nombre y estado', () => {
    class ConcreteProvider extends BaseProvider {
      async initiate() { return {}; }
    }
    const p = new ConcreteProvider('test', {});
    const meta = p.getMetadata();
    expect(meta.name).toBe('test');
    expect(meta.enabled).toBe(true);
  });

  test('initiate lanza error si no está implementado', async () => {
    class IncompleteProvider extends BaseProvider {}
    const p = new IncompleteProvider('incomplete', {});
    await expect(p.initiate({})).rejects.toThrow(/no está implementado/);
  });

  test('confirm lanza error si no está implementado', async () => {
    class IncompleteProvider extends BaseProvider {}
    const p = new IncompleteProvider('incomplete', {});
    await expect(p.confirm('TXN-1')).rejects.toThrow(/no está implementado/);
  });

  test('refund lanza error si no está implementado', async () => {
    class IncompleteProvider extends BaseProvider {}
    const p = new IncompleteProvider('incomplete', {});
    await expect(p.refund('TXN-1', 10)).rejects.toThrow(/no está implementado/);
  });
});
