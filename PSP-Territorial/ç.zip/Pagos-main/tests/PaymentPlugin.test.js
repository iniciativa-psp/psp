const PaymentPlugin = require('../src/PaymentPlugin');
const BaseProvider = require('../src/providers/BaseProvider');
const BaseIntegration = require('../src/integrations/BaseIntegration');
const PaymentStatus = require('../src/utils/PaymentStatus');
const FacturacionIntegration = require('../src/integrations/FacturacionIntegration');
const PedidosIntegration = require('../src/integrations/PedidosIntegration');
const ContabilidadDGIIntegration = require('../src/integrations/ContabilidadDGIIntegration');

const DEFAULT_CONFIG = {
  providers: {
    yappy: { merchantId: 'M1', secretKey: 'S1' },
    clave: { merchantId: 'M2', apiKey: 'K2' },
    banco_general: { merchantId: 'M3', apiKey: 'K3' },
    paguelofacil: { cclw: 'CCLW1' },
    paypal: { clientId: 'CID', clientSecret: 'CS', sandbox: true },
    transferencia_bancaria: { bankName: 'BNP', accountName: 'Empresa', accountNumber: '111' },
    transferencia_internacional: { bankName: 'GB', accountNumber: 'ACC', swiftCode: 'SWIFT1' },
    efectivo: { instructions: 'Pague en caja.' },
    punto_pago: { merchantId: 'M4', secretKey: 'S4' },
  },
};

const ORDER = { amount: 20, currency: 'USD', orderId: 'ORD-001', description: 'Test' };

describe('PaymentPlugin – constructor', () => {
  test('crea instancia con todos los proveedores predeterminados', () => {
    const plugin = new PaymentPlugin(DEFAULT_CONFIG);
    const names = plugin.listProviders().map((p) => p.name);
    expect(names).toEqual(expect.arrayContaining([
      'yappy', 'clave', 'punto_pago', 'banco_general',
      'paguelofacil', 'paypal', 'transferencia_bancaria',
      'transferencia_internacional', 'efectivo',
    ]));
  });

  test('se puede instanciar sin configuración', () => {
    const plugin = new PaymentPlugin();
    expect(plugin.listProviders()).toHaveLength(9);
  });
});

describe('PaymentPlugin – pay()', () => {
  test('pago con Yappy retorna PENDING', async () => {
    const plugin = new PaymentPlugin(DEFAULT_CONFIG);
    const result = await plugin.pay('yappy', ORDER);
    expect(result.status).toBe(PaymentStatus.PENDING);
    expect(result.provider).toBe('yappy');
  });

  test('pago con efectivo retorna AWAITING_CONFIRMATION', async () => {
    const plugin = new PaymentPlugin(DEFAULT_CONFIG);
    const result = await plugin.pay('efectivo', ORDER);
    expect(result.status).toBe(PaymentStatus.AWAITING_CONFIRMATION);
  });

  test('lanza error si el proveedor no existe', async () => {
    const plugin = new PaymentPlugin(DEFAULT_CONFIG);
    await expect(plugin.pay('inexistente', ORDER)).rejects.toThrow(/no encontrado/i);
  });

  test('retorna FAILED si el proveedor está deshabilitado', async () => {
    const plugin = new PaymentPlugin({
      providers: { yappy: { merchantId: 'M', secretKey: 'S', enabled: false } },
    });
    const result = await plugin.pay('yappy', ORDER);
    expect(result.status).toBe(PaymentStatus.FAILED);
  });
});

describe('PaymentPlugin – confirm()', () => {
  test('confirma un pago y retorna APPROVED', async () => {
    const plugin = new PaymentPlugin(DEFAULT_CONFIG);
    const result = await plugin.confirm('yappy', 'YAPPY-123');
    expect(result.status).toBe(PaymentStatus.APPROVED);
  });
});

describe('PaymentPlugin – refund()', () => {
  test('reembolsa un pago y retorna REFUNDED', async () => {
    const plugin = new PaymentPlugin(DEFAULT_CONFIG);
    const result = await plugin.refund('paypal', 'PP-123', 20);
    expect(result.status).toBe(PaymentStatus.REFUNDED);
  });
});

describe('PaymentPlugin – registerProvider()', () => {
  test('permite registrar un proveedor personalizado', async () => {
    class MiPagoProvider extends BaseProvider {
      constructor(cfg) { super('mi_pago', cfg); }
      async initiate() { return { status: PaymentStatus.PENDING, provider: this.name }; }
      async confirm() { return { status: PaymentStatus.APPROVED }; }
      async refund() { return { status: PaymentStatus.REFUNDED }; }
    }

    const plugin = new PaymentPlugin(DEFAULT_CONFIG);
    plugin.registerProvider(new MiPagoProvider({}));
    const result = await plugin.pay('mi_pago', ORDER);
    expect(result.status).toBe(PaymentStatus.PENDING);
    expect(result.provider).toBe('mi_pago');
  });
});

describe('PaymentPlugin – listProviders()', () => {
  test('listProviders(false) devuelve todos', () => {
    const plugin = new PaymentPlugin(DEFAULT_CONFIG);
    expect(plugin.listProviders()).toHaveLength(9);
  });

  test('listProviders(true) devuelve solo habilitados', () => {
    const plugin = new PaymentPlugin({
      providers: { yappy: { enabled: false } },
    });
    const enabled = plugin.listProviders(true);
    expect(enabled.every((p) => p.enabled)).toBe(true);
  });
});

describe('PaymentPlugin – isAvailable()', () => {
  test('retorna true si el proveedor existe y está habilitado', () => {
    const plugin = new PaymentPlugin(DEFAULT_CONFIG);
    expect(plugin.isAvailable('yappy')).toBe(true);
  });

  test('retorna false si el proveedor está deshabilitado', () => {
    const plugin = new PaymentPlugin({ providers: { yappy: { enabled: false } } });
    expect(plugin.isAvailable('yappy')).toBe(false);
  });

  test('retorna false si el proveedor no existe', () => {
    const plugin = new PaymentPlugin(DEFAULT_CONFIG);
    expect(plugin.isAvailable('inexistente')).toBe(false);
  });
});

describe('PaymentPlugin – integraciones', () => {
  test('notifica FacturacionIntegration al aprobar un pago', async () => {
    const plugin = new PaymentPlugin(DEFAULT_CONFIG);
    const facturacion = new FacturacionIntegration({ autoGenerate: true });
    const spy = jest.spyOn(facturacion, 'onPaymentApproved');
    plugin.registerIntegration(facturacion);

    await plugin.confirm('yappy', 'YAPPY-001');
    expect(spy).toHaveBeenCalledTimes(1);
  });

  test('notifica PedidosIntegration al aprobar un pago', async () => {
    const plugin = new PaymentPlugin(DEFAULT_CONFIG);
    const pedidos = new PedidosIntegration({});
    const spy = jest.spyOn(pedidos, 'onPaymentApproved');
    plugin.registerIntegration(pedidos);

    await plugin.confirm('clave', 'CLAVE-001');
    expect(spy).toHaveBeenCalledTimes(1);
  });

  test('notifica ContabilidadDGIIntegration al aprobar un pago', async () => {
    const plugin = new PaymentPlugin(DEFAULT_CONFIG);
    const contabilidad = new ContabilidadDGIIntegration({ ruc: '8-123-456' });
    const spy = jest.spyOn(contabilidad, 'onPaymentApproved');
    plugin.registerIntegration(contabilidad);

    await plugin.confirm('paypal', 'PP-001');
    expect(spy).toHaveBeenCalledTimes(1);
  });

  test('notifica integraciones al reembolsar', async () => {
    const plugin = new PaymentPlugin(DEFAULT_CONFIG);
    const facturacion = new FacturacionIntegration({});
    const spy = jest.spyOn(facturacion, 'onPaymentRefunded');
    plugin.registerIntegration(facturacion);

    await plugin.refund('yappy', 'YAPPY-001', 20);
    expect(spy).toHaveBeenCalledTimes(1);
  });

  test('un error en una integración no interrumpe el flujo', async () => {
    const plugin = new PaymentPlugin(DEFAULT_CONFIG);

    class BrokenIntegration extends BaseIntegration {
      constructor() { super('broken', {}); }
      async onPaymentApproved() { throw new Error('Error simulado'); }
    }

    plugin.registerIntegration(new BrokenIntegration());
    // No debe lanzar
    await expect(plugin.confirm('yappy', 'YAPPY-001')).resolves.toBeTruthy();
  });

  test('integración deshabilitada no es notificada', async () => {
    const plugin = new PaymentPlugin(DEFAULT_CONFIG);
    const pedidos = new PedidosIntegration({ enabled: false });
    const spy = jest.spyOn(pedidos, 'onPaymentApproved');
    plugin.registerIntegration(pedidos);

    await plugin.confirm('yappy', 'YAPPY-001');
    expect(spy).not.toHaveBeenCalled();
  });
});
