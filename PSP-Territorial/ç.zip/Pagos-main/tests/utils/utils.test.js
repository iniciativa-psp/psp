const PaymentStatus = require('../../src/utils/PaymentStatus');
const { Currency, formatAmount } = require('../../src/utils/Currency');

describe('PaymentStatus', () => {
  test('contiene todos los estados esperados', () => {
    expect(PaymentStatus.PENDING).toBe('PENDING');
    expect(PaymentStatus.PROCESSING).toBe('PROCESSING');
    expect(PaymentStatus.APPROVED).toBe('APPROVED');
    expect(PaymentStatus.DECLINED).toBe('DECLINED');
    expect(PaymentStatus.CANCELLED).toBe('CANCELLED');
    expect(PaymentStatus.REFUNDED).toBe('REFUNDED');
    expect(PaymentStatus.FAILED).toBe('FAILED');
    expect(PaymentStatus.AWAITING_CONFIRMATION).toBe('AWAITING_CONFIRMATION');
  });

  test('está congelado (no se pueden agregar propiedades)', () => {
    'use strict';
    expect(() => { PaymentStatus.NEW_STATE = 'NEW'; }).toThrow();
  });
});

describe('Currency', () => {
  test('contiene USD, EUR y PAB', () => {
    expect(Currency.USD).toBe('USD');
    expect(Currency.EUR).toBe('EUR');
    expect(Currency.PAB).toBe('PAB');
  });

  test('formatAmount formatea correctamente en USD', () => {
    expect(formatAmount(10, 'USD')).toBe('$10.00');
    expect(formatAmount(1.5, 'USD')).toBe('$1.50');
  });

  test('formatAmount formatea correctamente en EUR', () => {
    expect(formatAmount(20, 'EUR')).toBe('€20.00');
  });

  test('formatAmount formatea correctamente en PAB', () => {
    expect(formatAmount(5, 'PAB')).toBe('B/.5.00');
  });

  test('formatAmount usa la moneda como símbolo si no está mapeada', () => {
    expect(formatAmount(10, 'XYZ')).toBe('XYZ10.00');
  });

  test('formatAmount usa USD por defecto', () => {
    expect(formatAmount(100)).toBe('$100.00');
  });
});
